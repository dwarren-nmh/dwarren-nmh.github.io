### v1.4.5

* Add: Burner wifi set
* Add: ATOM support