import pyperclip

flash_cmd = "esptool.py --chip esp32 --port /dev/ttyUSB0 --baud 921600 write_flash -z --flash_mode dio --flash_freq 80m --flash_size detect {} firmware.bin"
arduino_cmd = "python /home/sakabin/Arduino/hardware/espressif/esp32/tools/esptool/esptool.py --chip esp32 --port /dev/ttyUSB0 --baud 921600 --before default_reset --after hard_reset write_flash -z --flash_mode dio --flash_freq 80m --flash_size detect 0xe000 /home/sakabin/Arduino/hardware/espressif/esp32/tools/partitions/boot_app0.bin 0x1000 /home/sakabin/Arduino/hardware/espressif/esp32/tools/sdk/bin/bootloader_dio_80m.bin 0x10000 /tmp/arduino_build_52334/X2lidarRemote.ino.bin 0x8000 /tmp/arduino_build_52334/X2lidarRemote.ino.partitions.bin"

def get_bin_file(cmd):
    file_list = []
    cmd_list = cmd.split(' ')
    for i in range(len(cmd_list)):
        if '0x' in cmd_list[i] and '.' not in cmd_list[i]:
            offset = '0x' + cmd_list[i].split('0x')[-1]
            file_list.append([int(offset, base=16), cmd_list[i+1]])
    file_list.sort(key = lambda x : x[0])
    return file_list


def cover_to_firmware(cover_list):
    cur_offset = cover_list[0][0]

    with open('firmware.bin', 'wb') as fout:
        for offset, file_in in cover_list:
            assert offset >= cur_offset
            fout.write(b'\xff' * (offset - cur_offset))
            cur_offset = offset
            with open(file_in, 'rb') as fin:
                data = fin.read()
                fout.write(data)
                cur_offset += len(data)
    print(flash_cmd.format(cover_list[0][0]))
    return True

if "esptool.py --chip esp32 --port" in pyperclip.paste():
    print("flash cmd from paster ...")
    cover_to_firmware(get_bin_file(pyperclip.paste()))
else:
    print("flash cmd from cmd ...")
    cover_to_firmware(get_bin_file(arduino_cmd))

